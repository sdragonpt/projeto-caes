export interface Autor{
    nome: string,
      apelido: string,
      idade: number,
      id:{
        curso: string,
        numero: string,
        turma: string
      }
  }