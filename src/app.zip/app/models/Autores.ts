export interface Autores{
    nome: string,
      numero: number,
      email: string
      
  }